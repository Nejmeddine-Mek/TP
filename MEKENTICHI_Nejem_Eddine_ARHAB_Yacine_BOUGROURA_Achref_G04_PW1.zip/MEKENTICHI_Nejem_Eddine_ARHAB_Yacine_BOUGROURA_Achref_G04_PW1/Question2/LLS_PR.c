#include "./Linked_LISTSAM.h"
void printing(numbers *head); // function prototype of the printing function, it is at the end of the code
//--------------------------------
void get_primes(numbers **P, int range,int *size); // function prototype of the primes filtering function ; the function is at the end of the code
//---------------------------------------

int iterates = 0; // we declare it as a global scope so that we don't pass it as an argument each time we call a function

int primes(numbers **P,int range, int *size)
{

 numbers *head, *Q, *current;
if(range  == 2)
{
    printf("The Only prime number is:  2"); // no need to create anything, as 2 is the only number in that range
}
else if( range < 2)
{
    printf("There are no prime numbers less than 2 !"); // there are no primes numbers less than 2!
}
else
{
    // Creating the first node
   INIT_LIST(&head);
   newcell(&head); // now we allocated some space in the memory to which head is pointing
   AS_VAL(&head,2);
   (*size) += sizeof(numbers);
   // assigning its @ to current so that we can work without losing the head of the list
   *P = head;
   current = head;
   // here we get odd numbers and we assign them to the data field of each created node
   for(int i = 3 ; i <= range; i+=2)
   {
       ++iterates;              // in this loop we simply generate odd numbers, to get prime numbers. then end up with a list
       newcell(&Q);             // of only prime numbers that we can use in next questions!
       (*size) += sizeof(numbers);
       AS_VAL(&Q,i);
       AS_ADR(&current,Q);
       current = Q;
   }
}
get_primes(&head, range, size);
return iterates;
}

//------------------------------------------------------------------------------------------
// This function is used to print values from each node !!
void printing(numbers *head)
{
    int order = 0;
while(head != NULL) // while head is not NIL
{
 if( order % 9 == 0) // this condition helps printing 9 numbers in each line!
 {
     printf("\n");
     order++;
 }

    printf("%3d  |", GET_VAL(head)); // here we print the value in each node
 order++;
  head = next(head); // we get to the next node!
}
}
// Here is the primes filtering function
//-----------------------------------------------------------------
void get_primes(numbers **P, int range, int *size)
{
   numbers *head = *P, *Q = next(*P);
   int sample = GET_VAL(next(head));// we use this variable to check the remainder of the division of each number by it
                                   // if we ever find 0, it means that number is a multiple of the sample so we delete it!
   while(pow(sample,2) <= range) // we check if the square of a number is in the range, if not we don't go through this loop
   {
       while(Q != NULL) // as long as the Q pointer is not NIL
       {
           ++iterates; // increment the number of iterations
           if(next(Q) != NULL && GET_VAL(next(Q)) % sample == 0) // whenever we get a multiple of that sample
           {
               DEL_NODE(&Q,size); // we delete the node of that number!
           }
           Q = next(Q); // we go to the next node...
       }
       head = next(head);
       sample = GET_VAL(head); // update the sample
       Q = next(head);

   }

}
//----------------------------------------------------------------------------------------------------------------


