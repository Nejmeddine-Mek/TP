#include "LINKED_LISTSAM.h"
#include "DYNARR_AM.h"
#include <time.h>
#include <stdlib.h>
#include <windows.h>
int structs_implementation(numbers **head,ARRAY **LIST) // to return the range for coming tasks!!
{
   BOOL MessageBeep(UINT uType);
    clock_t begin, end; // we will use theses variables to calculate execution time !!
    int iterates, size = 0; // iterates to find number of iterations and size will  be used to find space complexity!
int range,range2;

do{

system("cls"); // clear the screen
int choice = menu2();
switch(choice)
{
case 1:
          if(*head != NULL)     // if there is already a list of primes, we clear it, by freeing up the occupied space, so that we
      {                     // avoid memory leaks, for dynamic arrays, we free the space just after terminating this function, because
                            // we don't use it in any other function
          clear_list(*head);
       }
// linked lists presentation
     printf("Please enter a range: ");
     scanf("%d", &range);
     begin = clock(); // we take the time when the function starts working
       iterates = primes(head,range, &size); // here we call the function
     end= clock(); // then we take the time when the function finishes working
      printf("Now we print the result:  \n");
      printing(*head); // we printf the results
        sleep(1);
      printf("\nExecution time (starts after reading the range!): %3lf seconds", (double)(end-begin)/1000);// division by 1000 to get time in seconds
      printf("\nnumber of iterations(printing is not included): %3d", iterates);//
      printf("\nSpace complexity of this function is:  %3d bytes", size);//
        sleep(1);
    break;                                                                                         // without including the interruption time
case 2:
// here we go for the dunamix arrays, and everything is done analogously!
      printf("Please enter a range: ");
      scanf("%d", &range2);
     begin = clock();
       iterates = PRIMES_throARRAYS(LIST,range2,&size);
     end = clock();
     printf("\nNow, We print Results:  \n");
       sleep(1);
      prints(*LIST,size/sizeof(ARRAY)-1);
      printf("\nExecution time (starts after reading the range!): %3lf seconds", (double)(end-begin)/1000);//
      printf("\nnumber of iterations(printing is not included): %3d", iterates);//
      printf("\nSpace complexity of this function is:  %3d bytes", size);//
       sleep(1);
    free(*LIST); // we free the occupied space in memory by the array created
    break;
  case 3:
     goto quit;
    break;
default:
    MessageBeep(MB_ICONERROR);
    MessageBox(NULL,"Option not available!","ERROR", MB_OK | MB_ICONERROR); // we display an error message if the entered choice is not available

}
   sleep(1);
   MessageBeep(MB_ICONASTERISK);
}while(MessageBox(NULL,"Do you want to quit ?", "QUESTION", MB_YESNO | MB_ICONQUESTION) != 6); // we repeat until the user chooses to leave
quit:
return range; // we return the range to use it in coming functions
}


