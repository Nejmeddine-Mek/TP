#ifndef DYNARR_AM_H_INCLUDED
#include <stdbool.h>
#define DYNARR_AM_H_INCLUDED
// this is the structure we will be using

typedef struct { // this is the structure we will use
int number; // it will carry the number
bool prime; // and a boolean names prime so the number is either prime or not!
}ARRAY;


//initialize and create the array!
void INIT_AR(ARRAY **P,int siz)
{
    *P = (ARRAY *)malloc((siz)*sizeof(ARRAY));
}

//check for the value of the prime boolean
bool PRIME_STAT(ARRAY *P)
{
 return P->prime;
}

//return the value stored in that element!
int RET_VAL(ARRAY *P)
{
    return P->number;
}

// assign a given value to the field of the data
void AS_ELEMENT(ARRAY *Q,int val)
{
    Q->number = val;
}

// assign a given truth value to the field of the prime boolean 
void AS_PRM(ARRAY *Q,bool prm )
{
    (Q)->prime = prm;
}

// this is the filling function
void FILL_AR(ARRAY **P,int range,int size,int *iterating)
{
    int c = 1;
    AS_ELEMENT(((*P)+0),2); // the first element takes the value 2

    for(int i = 3; i <= range;i+=2) // then the rest takes values of odd numbers!
    {
        ++(*iterating);
        AS_ELEMENT(((*P)+c),i);
        AS_PRM(((*P)+c),1); // and we suppose they are all prime, then we eliminate
         ++c; // increment the index!
    }
}

#endif // DYNARR_AM_H_INCLUDED
