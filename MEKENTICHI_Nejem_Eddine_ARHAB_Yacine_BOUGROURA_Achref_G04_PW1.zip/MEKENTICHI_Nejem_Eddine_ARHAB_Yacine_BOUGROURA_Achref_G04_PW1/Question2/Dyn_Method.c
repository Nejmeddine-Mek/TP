#include "DYNARR_AM.h"
void prints(ARRAY *L, int size); // function prototype
int PRIMES_throARRAYS(ARRAY **LIST, int range,int *s);
//---------------------------------------------------------------------------------
//-----------------
int PRIMES_throARRAYS(ARRAY **LIST, int range,int *s)
{
    int iterates; // this variable wil count the number of iterations
    ARRAY *P;     // this pointer will point to a certain array
     int size = range/2+1;   // as long as we are going to generate odd numbers we can size to range /2 +1 to carry the value of 2!
     (*s) = size*(sizeof(ARRAY)); // we assign the same value to the content of the @ carried by s to be used later"
    INIT_AR(&P,size);             // we initialize our array
    FILL_AR(&P,range,size,&iterates); // we fill our array, by basically giving the range, the size and obviously the array as parameters
    for( int i = 0; i < size; i++)
    {
        int sample = RET_VAL((P+i)); // in the asm e way as the linked lists, we use some samples and we delete their multiples, not quite deleting them
                                     // but actually set the prime boolean to false, because we can't delete elements from an array
        for( int j = i+1 ; j < size ; j++)
        {
            ++iterates;
            if(PRIME_STAT((P+j)) == 1)
            {
            if(RET_VAL(P+j) % sample == 0) // whenever we find a multiple
            {
                AS_PRM((P+j),0); // we set the prime boolean field to false
            }
            }
        }
    }

    *LIST = P;    // list takes P, because we may use it later on!
 return iterates; // we return the number of iterations, the idea behind this is reducing the number of arguments to be passed each time we call this function
}

//------------------------------------------------
//----------------
void prints(ARRAY *L,int size) // this function does nothing but printing the elements of the array,
{
    int count = 0;
    for(int i = 0 ; i < size ; i++)
    {

        if(PRIME_STAT(L+i) == 1) // if the number is prime, we print it
        {
            printf("%3d  | ", RET_VAL(L+i));
            ++count;
                    if (count % 7 == 0 ) // this allows printing 9 numbers in each line!
        {
            printf("\n");
        }
        }
    }
}
