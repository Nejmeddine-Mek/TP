#include <stdbool.h>
#include <stdlib.h>
#include "../Question4/FACTLLSAM.h"
bool compare_factors(element P[], element Q[]); // all we will be doing is comparing the factors of each number, if there are no commun ones
                                                // then they are co-primes
int iteration = 0; // numebr of iterations
void CoPrimes(FACT *P)
{
 FACT *cmp= P, *tmp ;     // they will be used to go through the whole list
 clock_t end, begin = clock(); // these are used to calculate execution time
 printf("List of Co-primes: \n");
while (cmp != NULL)  // knowing that GCD(a,b) = GCD(b,a)
{                    // we will be comparing factors of the current node with the factors of all the rest and we keep progressing as
      int count = 0;              // the following example:
                    //        2     5       7      (2,5)(2,7)  instead of having    (2,5)(2,7)  while they're both
                    //              5       7      (5,7)                            (5,2)(5,7)  the same
                    //                      7                                       (7,2)(7,5)
    tmp = cmp; // we assign the @ held by the cmp var. to the tmp var. that we will use in the inner loop
                // we are just following the above reasoning
    while(tmp != NULL)
    {
      if(compare_factors(F_array(cmp),F_array(tmp)) == true) // whenever the function returns true, we print the co-prime numbers found
      {
          count ++;
        printf("(%5d,%5d)   |", X(cmp),X(tmp));
        if( count % 9 == 0)
        {

            printf("\n");
        }
      }
      tmp = NEXT_F(tmp); // we repeat this for each number
    }
    printf("\n");
    cmp = NEXT_F(cmp); //we proceed to the next node
}
end = clock();
// here are the statistics
printf("Execution time of this function is :  %3lf\n", (double)(end - begin)/1000);
printf("The number of iterations is :  %3d\n", iteration);

}
//-------------------------------------------------------------------
bool compare_factors(element P[], element Q[]) // this function compares the factors
{
    int i = 0,  j =0;
    while(P[i].number != 0)  // it just compares them one to one in the classic way
    {
        while (Q[j].number != 0)
        {                        // if we find a matching we return false, otherwise we return true at the end
          ++iteration;
            if( Q[j].number == P[i].number)
            {
                return false;
            }
            ++j;
        }
       ++i;
    }
    return true;
}
