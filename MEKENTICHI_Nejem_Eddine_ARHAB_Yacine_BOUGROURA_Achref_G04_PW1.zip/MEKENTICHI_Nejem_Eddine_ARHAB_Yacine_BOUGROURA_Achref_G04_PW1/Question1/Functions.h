#ifndef FUNCTIONS_H_INCLUDED
#include <math.h>
#define FUNCTIONS_H_INCLUDED

void print(int n); // function prototype, core is below!!

//--------------------------------------------------
//--------
bool stat_prime(int n, int * iteration) // here we just check if a number is prime or not in the classic way, we stop after reaching the square root of the given number
{
    bool res = true;
 for(int i = 2; i <= sqrt(n);i++)
 {
  ++(*iteration);
    if(n % i == 0) // if we ever find a divisor in the range we return false !!
    {
        res = false;
    }
 }
 return res;
}
//------------------------------------------------------------------
//---------- 
int generate(int n, bool sign) // here we generate numbers we will check
{                              // based on the theorem that states that all primes are of the form : 6*n +(-) 1
    if(sign == 1)
    {
        return 6*n+1;
    }
    else
    {
      return 6*n-1;
    }
}

//---------------------------------------------
//---------
void print(int n) // here is the printing function
{
  static int count = 0;
  printf("%3d   |", n);
  ++count;// counting for the next condition (printing eight numbers in each line )
  if(count % 7 == 0) // this condition allows us to print 8 numbers in each line!
  {
    printf("\n");
  }
}
#endif // FUNCTIONS_H_INCLUDED
