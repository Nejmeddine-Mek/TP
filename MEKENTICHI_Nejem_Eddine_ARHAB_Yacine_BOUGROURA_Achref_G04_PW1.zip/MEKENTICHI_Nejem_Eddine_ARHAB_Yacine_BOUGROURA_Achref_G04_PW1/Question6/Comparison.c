#include <time.h>
#include "../Question2/DYNARR_AM.h"
#include "../Question2/Linked_LISTSAM.h"
 // In this function, we use the same range on two methods
// then we compare the statistics of them (time, space and number of iterations)

void Compare()
{
int size1, size2, iterations1, iterations2;
clock_t begin1 , begin2, end1, end2;
int range;
printf("Enter a range:  ");
scanf("%d", &range);

ARRAY *list;
numbers *head;

begin1 = clock();
    primes(&head,range,&size1,&iterations1); // we create list of primes using linked lists
end1 = clock();

begin2 = clock();
 iterations2 = PRIMES_throARRAYS(&list,range,&size2); // here we create the same list using dynamic arrays
end2 = clock();

// and here we print the results
printf("=============================== result ==============================\n");
printf("Execution time of linked lists  :  %3.5lf Seconds\n",(double)(end1-begin1)/1000);
printf("Execution time of Dynamic Arrays:  %3.5lf Seconds\n",(double)(end2-begin2)/1000);
printf("_______________________________________________________________________\n");
printf("Space complexity of linked lists  :  %3d Bytes\n",size1);
printf("Space complexity of Dynamic Arrays:  %3d Bytes\n",size2);
printf("_______________________________________________________________________\n");
printf("Number of iterations of linked lists method  :  %3d \n", iterations1);
printf("Number of iterations of Dynamic Arrays method:  %3d \n", iterations2);
printf("_______________________________________________________________________\n");

sleep(1);
// this is a small summary
printf(" Notice that the dynamic arrays method takes more time because we can't delete unwanted elements, so we are forced to go through them all\n");
printf(" And that time gap between these methods enlarges as the range gets bigger and bigger even though the complexity of both algorithms is O(n^2)\n");
printf(" Due to the same reason, the dynamic arrays method takes more space and also requires more iterations\n");
printf(" Meanwhile, the linked lists allow us to delete unwanted elements, so we can iterate less times, use less space ,and thus less time\n");
printf("\nYet, the dynamic arrays method might be faster in some cases such as working on small ranges\n");
sleep(1);
}
