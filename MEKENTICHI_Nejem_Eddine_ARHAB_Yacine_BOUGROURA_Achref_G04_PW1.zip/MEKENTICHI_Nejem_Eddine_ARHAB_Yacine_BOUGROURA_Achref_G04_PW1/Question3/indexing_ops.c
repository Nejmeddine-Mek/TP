#include <windows.h>
int indexing_ops(numbers *head,int range)
{
    int choice,up,down,target;
   do
   {
    choice = INdexMENU();
    switch (choice)
    {
    case 1:
     //---------------------------------------------------
           printf("PLease enter a lower bound: ");
            scanf("%d", &down);
            while(down < 0 || down >= range)
            {
                printf("There are no negative primes, please enter a postive value that is greater than or equal to 2 :  ");
                scanf("%d", &down);
                // here we make sure that the lower bound is positive and less than range so that we don't run into some errors
                // let me say a contradiction caused by our own conditions
            }
            printf("PLease enter an upper bound: ");
            scanf("%d", &up);
            while( up > range || up < down)
            {  // and here we just force the user to enter an appropriate upper bound that is less than or equal to range and also greater then the lower bound
                printf("The upper bound you entered is too big so that is exceeds %d, or it is less than \n", range);
                printf(" The lower bound\n");
                printf("ENter a new upper bound or type in -1 to create a new list with a new range");
                scanf("%d", &up);
                //----------------------------------------
                 if(up == -1)
                {                         // in order not to make the user repeat his choice in the main menu, we create this loop, so that
                                        // we force them to enter som kind of a valid range [lower bound ...... upper bound], or if they want to
                                      // create a bigger list for that range, they can enter -1 and then go to create a new list to work with it!
                    /* More explanation:
                         here, we make sure that all conditions are satisfied;
                         1/  up >> down
                         2/  up is withing the range
                         3/ up > 0, just by making sure that down is positive and greater than or equal to 2



                    */
                    return -1;
                }
            }
            displayall_primes_between_two_values(head,up,down); // we get the list and withing the function we get the upper and the lower bounds,

        break;
    case 2:   // this case was YACINE's idea, where he uses the indexing optimized method to search for prime numbers not just a list of primes
             // between two values
    printf("Please enter a number to look for");
    scanf("%d", &target);
    elt_search(head,target);
        break;
    case 3:
         return 0; // this is the quitting case
        break;
    default:
      printf("Option not available!"); // this thing is not even necessary, because the choice is actually oriented by that keyboard controlled menu
                                      // so the returned value is always between 1 and 3
        break;
    }
   }while(MessageBox(NULL,"DO you want to quit this menu?","Question", MB_YESNO | MB_ICONQUESTION) != 6);

    return 0;
}
