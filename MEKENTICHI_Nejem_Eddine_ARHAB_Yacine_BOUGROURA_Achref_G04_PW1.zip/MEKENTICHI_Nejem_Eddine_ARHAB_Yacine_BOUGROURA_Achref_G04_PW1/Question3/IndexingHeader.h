#ifndef INDEXINGHEADER_H_INCLUDED
#include "../Question2/Linked_LISTSAM.h"

#define INDEXINGHEADER_H_INCLUDED

typedef struct indexedlist{
    int data;
    struct indexedlist* next;
    struct indexedlist* nextindex;
}indexedlist;

//sub list abstract machine
// __________________________________________________________________


//create a newwcell
void subnewcell(indexedlist **P)
{

    *P = (indexedlist *)malloc(sizeof(indexedlist));
    (*P)->next = NULL;
    (*P)->nextindex=NULL;
}
// assigning the address of the next to the current's next field (field of next in the current numbers takes the @ of the next numbers)
void subAS_ADR(indexedlist **P, indexedlist *Q)
{
   (*P)->next = Q;
}
// assigning next index address to the previous index address
void subAS_idADR(indexedlist **P, indexedlist *Q)
{
   (*P)->nextindex = Q;
}
// assigning value
void subAS_VAL(indexedlist **P, int val)
{
    (*P)->data = val;
}
// Note that the argument must be the head!!
bool subIS_EMPTY(indexedlist *head)
{
    return head == NULL;
}
// getting value from a node
int subGET_VAL(indexedlist *P)
{
    return P->data;
}

// going to the next node in sub list
indexedlist *subnext(indexedlist *P)
{
    return P->next;
}
// going to the next index node by the SPECEFIC GIVEN RANGE
indexedlist *subnextindex(indexedlist *P)
{
    return P->nextindex;
}

void give_range(int* idrange){
    printf("enter the range uwant to index the LLC with: ");
    int idrange1;
    scanf("%d",&idrange1);
    if (idrange1<=0){
        printf("in valid too small range!!\n");
        return;
    } *idrange=idrange1;
}
// _______________________________________________________________________________________

#endif // INDEXINGHEADER_H_INCLUDED
