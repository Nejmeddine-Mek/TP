void intro()
{
system("cls");
system("COLOR B");
printf("                         ______________       ______________      ____________            \n");
printf("                        /     ________/      /     ________/     /___     ___/      \n");
printf("                       /    /________       /     /________          /   /           \n");
printf("                      /     ________/      /_________     /         /   /       \n");
printf("                     /    /________        _________/    /      ___/   /___         \n");
printf("                    /_____________/       /_____________/      /__________/      \n");
printf("\n                       Higher national School Of Computer Science                      \n");
printf("\n");
printf("Practical work number 1 (TP1) of algorithms and data structures.\n");
printf("WORK realized by:  \n");
printf("     - MEKENTICHI Nejem Eddine\n");
printf("     - ARHAB Yacine \n");
printf("     - BOUGROURA Achref \n");
printf("\n");
printf("Press any key to continue....");
}
//---------------------------------------------------------------------------------------------------------
//----------------------------- Indexing menu
int INdexMENU()
{
   int position = 1, key =0;
while( key != 13)
{
   system("cls");
   arrow(1,3);         printf("====================================== Menu of Indexing ================================\n");
   arrow(1,position);  printf("                                        Print by range                                        \n");
   arrow(3,position);  printf("                                  Search for a prime number                                        \n");
      arrow(2,position);  printf("                                           Quit                                     \n");
   arrow(3,7);         printf("=========================================================================================\n");
   key = getch();
   if( key == 80)
   {
      position++;
      if( position ==4)
      {
         position = 1;
      }
   }
   else if( key == 72)
   {
      position --;
      if(position == 0)
      {
         position = 3;
      }
   }
}
return position;
}
//-----------------------------------------------------------------------------------------------------------------------------
//--------------------- Second menu!! --
int menu2()
{  // key holds the ascii code of the pressed key
   // position is the selected option
    int key = 0, position = 1;
    while( key != 13) // while we didn't click on enter
    {
     system("cls");
  arrow(1,3);           printf(" \n         =================================Menu of available operation=================================\n");
  arrow(1,position);    printf("                                        Implementation Using linked lists                              \n");
  arrow(2,position);    printf("                                       Implementation Using dynamic arrays                              \n");
  arrow(3,position);    printf("                                                      Quit                                          \n");
  arrow(1,3);           printf("          =============================================================================================\n");

  key = getch(); // we read some ascii code of a key pressed by a user
 if(key == 80 ) // if they press down arrow
 {
    position++; // we go to the option below
    if(position == 4) // if we exceed the available options, we go to the first option again
    {
        position = 1;
    }
 }
 else if( key == 72) // if they press the up key we go to the previous option 
 {                 // the rest is done analogously
    position--;
        if(position == 0)
    {
        position = 3;
    }
 }

} // if ever the user presses enter we return the value held by the variable position
return position;  
 }
 //-------------------------------------------------------
//---------------------------------------
// this function is analogous to the one above

int menu()
{
int position = 1;
int keypressed = 0;

while( keypressed != 13)
{
system("cls");
arrow(0,2); printf("          =================================Menu of available operation=================================\n"); 
arrow(1,position); printf("\n                           Get list of prime numbers in a given range (Quick display)                  \n"); 
arrow(2,position); printf("                     Get Prime numbers of a given range using dynamic arrays or linked lists                   \n"); 
arrow(3,position); printf("                                               Print by range                                  \n");
arrow(4,position); printf("                                      Factorize a list into Prime factors                                 \n");
arrow(5,position); printf("                                           Get a list of Co-Primes!                                 \n");
arrow(6,position); printf("                                            Compare both methods                                     \n");
arrow(7,position); printf("                                                    Exit                                        \n");
arrow(0,2); printf("\n          =============================================================================================\n");
//-------------------------------------------------------
 keypressed = getch(); 


 if(keypressed == 80 )
 {
    position++;
    if(position == 8)
    {
        position = 1;
    }
 }
 else if( keypressed == 72)
 {
    position--;
        if(position == 0)
    {
        position = 7;
    }
 }
}
return position;
}
//-------------------------------------------------------------------------------------------
//-----------------------
void arrow(int realposition, int arrowposition) // this one here is the one used to highlight a certain option
{
 if (realposition == arrowposition) // is the arrow position is equal to the postion we print that line in a blue colour
 {
    printf("\033[1;34m"); // this is the bash colour code for blue
    
 }
 else
 {
    printf("\033[0;37m"); // else we print the line in a light grey colour and that is its bash code
 }
}