#include <stdlib.h>
#include "../Question2/Linked_LISTSAM.h"
#include "./FACTLLSAM.h"
void printcell(element Q[], FACT *O);             // printing the factorization
void prime_factors(element Q[],numbers *P,int n); // factorizing
int iter = 0, space_complex = 0;                        // iterations, and space complexity


void Factorize(int range,FACT **FACTORIZE, numbers *list) // we need a pointer to the list of prime numbers to use it in the
                                                          // factorization
{
  if( *FACTORIZE != NULL) // if we already have a list, we free it, then we proceed
  {
    CLEAR_LIST(*FACTORIZE);
  }

  clock_t end, begin = clock();       // these are for execution time calculation
  numbers *temp;              // temporar pinter to be used instead of list itself
  FACT *head, *current, *tail;
   head = NULL;

  NEWFACT(&head); // initialize the list of the factorized numbers!
  AS_N(&head,2); // first node takes the number 2
  space_complex += sizeof(FACT); //increment the size
  current = head;
   for( int i = 3 ; i <= range ; i++) // in this loop all we do is creating the list and assigning number sto nodes
   {
    NEWFACT(&tail);
    space_complex += sizeof(FACT); // each allocation => increasing the space complexity
    AS_N(&tail,i);
    AS_NEXT(&current,tail);
    current = tail;
   }
     current = head;
   while(current != NULL) // now we go through our list and factorize each number
   {
    temp = list;
    prime_factors(F_array(current),temp,current->x); // here we factorize
    printcell(F_array(current),current); // we also print each number with its factors
    current = NEXT_F(current);
   }
   *FACTORIZE = head; // we assign head to FACTORIZE as we will use this list later
   end = clock(); 

    // here are statistics of this function            
   printf("\nExecution time:  %3lf seconds\n", (double)(end - begin)/1000);
   printf("Number of iterations (printing not included):  %3d \n", iter);
   printf("Space complexity: %d \n", space_complex);
}
//---------------------------------------------------------------------------
void printcell(element Q[],FACT *O) // this function prints the factorized numbers
{
  int i = 0;
  printf("%d  = ", X(O));
  while(Q[i].number != 0) // while the value held in the number field isn't 0, we print the numbers with their powers
                          // that is  a very basic function, it is easy to understand
  {
    printf("%d^%d", Q[i].number, Q[i].power);
    if( Q[i+1].number != 0)
    {
      printf(" * ");
    }
    ++i;
  }
  printf("\n");
}

//-------------------------------------------------------
void prime_factors(element Q[],numbers *P,int n) // this function factorizes each given number
{
 int power;
 int sample = GET_VAL(P); // each time we get an element from the list of primes
                          // then we keep dividing by it while the remainder is 0, and we keep incrementing the power
                           // and decrementing the number n
                          // when the remainder is not 0, we change the prime number all the way until n = 1
 int i = 0;
 while(n != 1)  // here we keep dividing while n <>  1
 {
  power = 0;
  while( n % sample == 0)  // we keep dividing here whenever we find a divisor
  {
    ++iter;
   ++power;
   n= n / sample;
   if(n % sample != 0) // when we get the multiplicity of that divisor we do the 
                      // following assignments
   {
     Q[i].power = power ;
     Q[i].number = sample;
     ++i; // we also increment the index
   }
  }
  if(next(P) != NULL) // this condition helps avoiding the access violation problem
                      // basically, sometimes, we reach the last element of the list of primes, when finishing the first operation
                      // we try to assign the value held by a NULL pointer to a variable which creates an error
  {
      P = next(P);
      sample = GET_VAL(P);
  }
 } 
 // then at the end we set the last element to 0, to be a mark for the end when printing
 Q[i].number = 0;
}