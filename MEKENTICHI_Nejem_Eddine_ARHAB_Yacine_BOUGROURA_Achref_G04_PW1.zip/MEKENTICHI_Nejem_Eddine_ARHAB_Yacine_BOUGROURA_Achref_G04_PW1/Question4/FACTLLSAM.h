#ifndef FACTLLSAM_H_INCLUDED
#include <stdlib.h>
#define FACTLLSAM_H_INCLUDED


typedef struct
{ // this structure holds the number with its power(number of repetitions)
    int number;
    int power;

}element;
//-----------------------------------

typedef struct
{ // this one will have the number, @ of the next node, and the array of the above struct that will contain the factorization
    int x;
    element factors[16]; // we use a static array of size 16 is fine, if we suppose that we fill the whole array with factors of power 1,
                          // it will  be very large ; it is in the scale of tens of septillions (i.e: 10^25) (the smallest possible number is going to be 2*3*5*7*11*13*17*19*23*29*31*37*41*43*47*53)
    struct FACT *next;
}FACT;

//----------------------------------------------------------------------------------------
//------------------------------- this part for the FACT structure -----------------------
void INIT_FACT(FACT **P)
{
    *P =NULL;            // initialize
}


void NEWFACT(FACT **P)
{
    *P = (FACT *)malloc(sizeof(FACT));  // new cell creation
    (*P)->next = NULL;
}


// assign some data
void AS_N(FACT **P, int n)
{
    (*P)->x = n;
}


// assign the @ of the next node
void AS_NEXT(FACT **P,FACT *Q)
{
    (*P)->next = Q;
}


//get the @ of the next node
FACT *NEXT_F(FACT *P)
{
    return P->next;
}


// get the @ of the array
int *F_array(FACT *P)
{
    return P->factors;
}


// get the value stored (the number stored in that node)
int X(FACT *P)
{
    return P->x;
}
//----------------------------------------------------------------------------------------
void CLEAR_LIST(FACT *head)
{
    FACT *temp;
    while(head != NULL)
    {
        temp = head;
        head = NEXT_F(head);
        free(temp);
    }
}
#endif // FACTLLSAM_H_INCLUDED
