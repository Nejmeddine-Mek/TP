void GET_PRIMES() // here is the main function
{
    clock_t begin, end;
  int range;
  int n = 1;
  bool sign = true; // the name of the variable literally means its use, true for + and  false for - (the opposite of the machine representation of the sign if T == 1 and F == 0)
  int number = 0; //  here we will store the generated numbers
  printf("Please enter a range:  ");
  scanf("%d", &range);
  begin = clock();
  if( range == 2) // if the range is 2, nothing will happen so we will just print what follows
  {
    printf("The only prime number is 2");
  }
  else if( range == 3 || range <= 4) // same thing if the range is 3 we just print 2 and 3
  {
    printf("Prime numbers in this range are:  2 and 3"); // I kept this portion for a linguistic reason, when you have two things to list, it is better to use and
  }                                                      // instead of another separator like , or something similar !!
  else if( range < 2) // if this condition si true, it would cause some trouble, so basically, we print that there are no primes less than 2!!
  {
    printf("There are no prime numbers less than 2");
  }
  else // now here comes the real work, if the range is greater than 3, we can go for thw following!
  {
    printf("Prime numbers in range <= %d are: \n", range);
    print(2);  // here is just a printing section!
    print(3);
    while (true)
    {
      iterations(); // number of iterations!!
      number = generate(n,!sign); // generate a number
      if(number > range) // verify that it is in this range
      {
        break; // if not, we break out of the loop and we're done
      }
      if(stat_prime(number)) // check if the number is prime...
      {
       print(number); // if so, print it!
      }
      number = generate(n,sign); // same as before, but, instead of - we go for +, so that our list will be sorted
            if(number > range) // if number > range we break out
      {
        break;
      }
      if(stat_prime(number)) // if it is prime, we print it !
      {
       print(number);
      }
      n++; // incrementing n, n is the number we use in generating possible prime numbers 6*n +- 1
    }

  }
  end = clock();
  printf("\n Execution time (timer starts when receiving a range!): %3.4lf seconds", (double)(end-begin)/1000);
    printf("\n Number of iterations:  %d", iterations());
}
