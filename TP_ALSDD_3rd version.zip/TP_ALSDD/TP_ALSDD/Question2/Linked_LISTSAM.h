#ifndef LINKED_LISTSAM_H_INCLUDED
#include <stdbool.h>
#include <stdlib.h>
#define LINKED_LISTSAM_H_INCLUDED
// This is the abstract machine of that contains essential operations on linked lists
//This is the data structure we will be using!
typedef struct
{
  int data;

  struct numbers *next;
}numbers;
void INIT_LIST(numbers **H);
void newcell(numbers **P);
void AS_ADR(numbers **P, numbers *Q);
//-------------------------------------------
// Create head
void INIT_LIST(numbers **H)
{
    *H = NULL;
}
// create new cell
void newcell(numbers **P)
{

    *P = (numbers *)malloc(sizeof(numbers));
    (*P)->next = NULL;
}
// assigning the address of the next to the current's next field (field of next in the current node takes the @ of the next node)
void AS_ADR(numbers **P, numbers *Q)
{
   (*P)->next = Q;
}
// assigning value
void AS_VAL(numbers **P, int val)
{
    (*P)->data = val;
}
// assigning the prime value true/false (0/1)

//getting the @ of the next node
numbers *next(numbers *P)
{
    return P->next;
}
// is the list empty
// Note that the argument must be the head!!
bool IS_EMPTY(numbers *head)
{
    return head == NULL;
}
// getting value from a node
int GET_VAL(numbers *P)
{
    return P->data;
}
// is this number prime or not ?

// assigning indexes to Prime numbers in the List "ONly primes, for non-primes, they remain unidentified !"

// deleting a node !
void DEL_NODE(numbers **prev,int *space)
{
    *space -= sizeof(numbers);
    numbers *temp = next(*prev);
    AS_ADR(prev,next(next(*prev)));
    free(temp);
}
#endif // LINKED_LISTSAM_H_INCLUDED
