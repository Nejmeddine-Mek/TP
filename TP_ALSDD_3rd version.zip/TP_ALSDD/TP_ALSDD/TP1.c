#include <stdio.h> // we are including necessary headers and files !
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <stdbool.h>  
#include "Question2/Linked_LISTSAM.h" // Abstract machine of linked lists
#include "Question2/impl_using_stucts.c" // implementation using complex structres (linkde lists, dynamic arrays)
#include "Question2/LLS_PR.c" // linked lists presentation
#include "Question1/Functions.h" // static presentaion functions
#include "Question1/Static_Representation.c" // static representation main 
#include "Question2/DYNARR_AM.h" // dynamic arrays abstract machine
#include "Question2/Dyn_Method.c" // dynamic arrays implementaiton
#include "Question3/Comparison.c" // comparison between both methods
#include "Question4/FACTLLSAM.h" // factorization structure abstract machine
#include "Question4/FACTORIZE.c" // the implemetnation of the factorization
#include "CoPrimes/COPrimes.c" // coprimes
#include "intro.c" // intro
#include "Indexing/indexing.c" // indexing by range
// Here our program begins
int main(char args, int *argv[])
{
    intro();
    getch();
    ARRAY *V; // this pointer will oint to the array we will create !
    numbers *head = NULL; // this one will point to the head of the list
    FACT *ListOfFactors = NULL; // this will point to the head of the lists of factorized numbers
system("COLOR B"); // set colour to light blue
BOOL MessageBeep(UINT uType);// This will make some sounds later on!
int response,range; // we will  use these variables to read some input 

do{
   system("cls"); // we clear the screen
//---------------------------------------------------Menu-----------------------------------------------
//------------------------------------------------------------------------------------------------------
printf("          =================================Menu of available operation=================================\n"); // a vary simple menu here
printf("\n                           Get list of prime numbers in a given range (Quick display)                  \n"); // with all things
printf("                     Get Prime numbers of a given range using dynamic arrays or linked lists                   \n"); // we will be providing
printf("                                            Compare both methods                                     \n");
printf("                                               Print by range                                  \n");
printf("                                      Factorize a list into Prime factors                                 \n");
printf("                                           Get a list of Co-Primes!                                 \n");
printf("          =============================================================================================\n");
        printf("\nPlease enter your choice:  ");
        int choice = 0;
        scanf("%d", &choice);
        switch(choice)
        {
        case 1:
            // getting quick display
            GET_PRIMES(); // calling the function 
            break;
        case 2:
        // we redirect the user where they will choose either linked lists presentation or dynamic arrays representation 
           range = structs_implementation(&head,&V);
            break;
        case 3:
        // we compare the stuctures 
            Compare();  // here we call the function that does the comparison for us
                        // Just to clarify a point, we redirect the user to this function regardless of his previous choices
                        // i.e: we don't consider the created linked list or array, because they may have different ranges so 
                        // the comparison won't be fair, hence we ask for one range and do the whole work again, on the same range 
                        // then we display the result
            break;
        case 4:
        // we index the list then we print by index
        if(head == NULL)
        {
            printf("You must create a list of prime numbers first!\n");
        }
        else
        {
            printbyindex(head);

        }
            break;
        case 5:
        // primes factorization
            if(head == NULL)
            {
                printf("You must Create a list of prime numbers first (using linked lists)!"); // obviously, the creation of the list 
                                                                                            // is necessary to progress
            }
            else
            {
              Factorize(range,&ListOfFactors,head); // i it it created we go forwards and factorize
            }
            break;
        case 6:
        // co primes!!
        if( ListOfFactors == NULL)
        {
            printf("\nYou must get the list of factorized numbers first! it is option 5 in the main menu!"); // again, the list of factorized
                                                                                                          // numbers is necessary
        }
        else
        {
         CoPrimes(ListOfFactors); // if it exists we proceed to the function
        }
            break;
        default:
            MessageBeep(MB_ICONERROR); // if we run into some errors, this command makes an error sound
            MessageBox(NULL,"Option not available","ERROR", MB_ICONERROR| MB_OK); // and this here displays a message box indicating that 
                                                                               // the chosen option is not available
            break;
        }
            sleep(3); // delay of 3 seconds before proceeding
   MessageBeep(MB_ICONASTERISK); // here an informatin sound 
   response = MessageBox(NULL,"Would you like to quit the program?","Message",MB_ICONQUESTION | MB_YESNO); // we ask if the user wants to quit or not!
}while(response != IDYES); // we quit if their response is yes!

    return 0;
}

