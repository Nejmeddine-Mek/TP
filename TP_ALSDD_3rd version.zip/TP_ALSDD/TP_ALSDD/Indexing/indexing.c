#include "../Question2/Linked_LISTSAM.h"
void printbyindex(numbers *list)
{
   int count = 0,up,down;
   printf("Enter the upper bound:  ");
   scanf("%d", &up);
   printf("Enter the lower bound:  ");
   scanf("%d", &down);
   system("cls");
   printf("List of primes between %d and %d :\n", down, up);
    while(list != NULL)
    {
        if(GET_VAL(list) >= down && GET_VAL(list) <= up)
        {
            ++count;
            printf("%3d  |", GET_VAL(list));
            if( count % 9 ==0)
            {
                printf("\n");
            }
        }
        list = next(list);
    }
}