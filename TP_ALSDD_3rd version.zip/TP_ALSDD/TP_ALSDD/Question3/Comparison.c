#include <time.h>
#include "../Question2/DYNARR_AM.h"
#include "../Question2/Linked_LISTSAM.h"

void Compare()
{
int size1, size2, iterations1, iterations2;
clock_t begin1 , begin2, end1, end2;
int range;
printf("ENter a range:  ");
scanf("%d", &range);
ARRAY *list;
numbers *head;
begin1 = clock();
 iterations1 = primes(&head,range,&size1);
end1 = clock();
begin2 = clock();
 iterations2 = PRIMES_throARRAYS(&list,range,&size2);
end2 = clock();
printf("=============================== result ==============================\n");
printf("Execution time of linked lists  :  %3.5lf Seconds\n",(double)(end1-begin1)/1000);
printf("Execution time of Dynamic Arrays:  %3.5lf Seconds\n",(double)(end2-begin2)/1000);
printf("_______________________________________________________________________\n");
printf("Space complexity of linked lists  :  %3d Bytes\n",size1);
printf("Space complexity of Dynamic Arrays:  %3d Bytes\n",size2);
printf("_______________________________________________________________________\n");
printf("NUmber of iterations of linked lists method  :  %3d \n", iterations1);
printf("NUmber of iterations of Dynamic Arrays method:  %3d \n", iterations2);
printf("_______________________________________________________________________\n");
}