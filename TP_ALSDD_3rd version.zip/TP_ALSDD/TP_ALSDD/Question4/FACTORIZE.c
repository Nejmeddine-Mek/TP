#include <stdlib.h>
#include "../Question2/Linked_LISTSAM.h"
#include "./FACTLLSAM.h"
void printcell(element Q[], FACT *O); // printing the factorization
void prime_factors(element Q[],numbers *P,int n); // factorizing

int iter = 0, space_complex = 0; // iterations, and space complexity
void Factorize(int range,FACT **FACTORIZE, numbers *list) // we need a pointer to the list of prime numbers to use it in the
                                                          // factorization
{clock_t end, begin = clock(); // these are for execution time calculation
  numbers *temp; // temporar pinter to be used instead of list itself
  FACT *head, *current, *tail;
   head = NULL;
  NEWFACT(&head); // initialize the list of the factorized numbers!
  AS_N(&head,2); // first node takes the number 2
  space_complex += sizeof(FACT); //increment the size
  current = head;
   for( int i = 3 ; i <= range ; i++)
   {
    NEWFACT(&tail);
    space_complex += sizeof(FACT);
    AS_N(&tail,i);
    AS_NEXT(&current,tail);
    current = tail;
   }
     *FACTORIZE = head;
     current = head;
   while(current != NULL)
   {
    temp = list;
    prime_factors(F_array(current),temp,current->x);
    printcell(F_array(current),current);
    current = NEXT_F(current);
   }
   end = clock();
   printf("\nExecution time:  %3lf seconds\n", (double)(end - begin)/1000);
   printf("Number of iterations (printing not included):  %3d \n", iter);
   printf("Space complexity: %d \n", space_complex);
}
//---------------------------------------------------------------------------
void printcell(element Q[],FACT *O)
{
  int i = 0;
  printf("%d  = ", X(O));
  while(Q[i].number != 0)
  {
    printf("%d^%d", Q[i].number, Q[i].power);
    if( Q[i+1].number != 0)
    {
      printf(" + ");
    }
    ++i;
  }
  printf("\n");
}

//-------------------------------------------------------
void prime_factors(element Q[],numbers *P,int n)
{
 int power;
 int sample = GET_VAL(P);
 int i = 0;
 while(n != 1)
 {
  power = 0;
  while( n % sample == 0)
  {
    ++iter;
   ++power;
   n= n / sample;
   if(n % sample != 0)
   {
     Q[i].power = power ;
     Q[i].number = sample;
     ++i;
   }
  }
  if(next(P) != NULL)
  {
      P = next(P);
      sample = GET_VAL(P);
  }
 }
 Q[i].number = 0;
}
