void intro()
{
system("cls");
system("COLOR B");
printf(" HIGHER NATIONAL SCHOOL  OF COMPUTER SCIENCE ESI- ALGIERS \n");
printf("\n");
printf("TP1 of algorithms and data structures.\n");
printf("WORK realized by:  \n");
printf("Practical work number 1 (TP1) of algorithms and data structures.\n");
printf("     - MEKENTICHI Nejem Eddine\n");
printf("     - ARHAB Yacine \n");
printf("     - BOUGROURA Achref \n");
printf("\n");
printf("Press any key to continue....");
}