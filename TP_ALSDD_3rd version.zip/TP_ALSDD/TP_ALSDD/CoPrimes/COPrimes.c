#include <stdbool.h>
#include <stdlib.h>
#include "../Question4/FACTLLSAM.h"
bool compare_factors(element P[], element Q[]); // all we will be doing is comparing the factors of each number, if there are no commun ones
                                                // then they are co-primes
int iteration = 0; // numebr of iterations
void CoPrimes(FACT *P)
{
 FACT *cmp= P, *tmp ;
 clock_t end, begin = clock(); // these are used to calculate execution time
 printf("List of Co-primes: \n");
while (cmp != NULL)
{
    tmp = cmp;
    while(tmp != NULL)
    {
      if(compare_factors(F_array(cmp),F_array(tmp)) == true)
      {
        printf("(%3d,%3d)   |", X(cmp),X(tmp));
      }
      tmp = NEXT_F(tmp);
    }
    printf("\n");
    cmp = NEXT_F(cmp);
}
end = clock();
printf("Execution time of this function is :  %3lf\n", (double)(end - begin)/1000);
printf("The number of iterations is :  %3d\n", iteration);

}
//-------------------------------------------------------------------
bool compare_factors(element P[], element Q[])
{
    int i = 0,  j =0;
    while(P[i].number != 0)
    {
        while (Q[j].number != 0)
        {
          ++iteration;
            if( Q[j].number == P[i].number)
            {
                return false;
            }
            ++j;
        }
       ++i; 
    }
    return true;
}