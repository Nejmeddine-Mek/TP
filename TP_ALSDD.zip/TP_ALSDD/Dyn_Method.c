#include "Question2/DYNARR_AM.h"
void PRIMES_throARRAYS(ARRAY **LIST, int range)
{
    ARRAY *P = *LIST;
    int size = range/2+1;
    CREATE(&P,size);
    FILL_AR(&P,range,size);
 // we filled our array!
    for( int i = 0; i < size; i++)
    {
        int sample = RET_VAL((P+i));
        for( int j = i+1 ; j < size ; j++)
        {
            if(RET_VAL(P+j) % sample == 0)
            {
                (P+j)->prime = 0;
            }
        }
    }
    for(int i = 0 ; i < size ; i++)
    {
        if(PRIME_STAT(P+i) == 1)
        {
            printf("%3d   ", RET_VAL(P+i));
        }
    }
}
