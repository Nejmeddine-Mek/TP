void printing(numbers *head); // function prototype of the printing function, it is at the end of the code
//--------------------------------
void get_primes(numbers **P, int range,int *size); // function prototype of the primes filtering function ; the function is at the end of the code
//---------------------------------------
int space_complexity_LLS();
int iterates = 0; // we declare it as a global scope so that we don't pass it as an argument each time we call a function
void primes(numbers **P,int range)
{
int size = 0;
numbers *head, *Q, *current;
create(&head);
if(range  == 2)
{
    printf("The Only prime number is:  2"); // no need to create anything, as 2 is the only number in that range
}
else if( range < 2)
{
    printf("There are no prime numbers less than 2 !");
}
else
{
    // Creating the first node
   create(&head); // head is equal to NULl right now
   newcell(&head); // now we allocated some space in the memory to which head is pointing
   AS_VAL(&head,2);
   size += sizeof(numbers);
   // assigning its @ to current so that we can work without losing the head of the list
   *P = head;
   current = head;
   // here we get odd numbers and we assign them to the data field of each created node
   for(int i = 3 ; i <= range; i+=2)
   {
       ++iterates;              // in this loop we simply generate odd numbers, to get prime numbers. then end up with a list
       newcell(&Q);             // of only prime numbers that we can use in next questions!
       size += sizeof(numbers);
       AS_VAL(&Q,i);
       AS_ADR(&current,Q);
       current = Q;
   }
}
get_primes(&head, range, &size);
//Printing the results!!
printing(head);
printf("\n Number of iterations:    %d",iterates);
printf("\n Space complexity (only the structure was taken in consideration):  %d bytes", size);
}

//------------------------------------------------------------------------------------------
// This function is used to print values from each node !!
void printing(numbers *head)
{
    int order = 0;
while(head != NULL)
{
 if( order % 9 == 0)
 {
     printf("\n");
     order++;
 }

    printf("%3d  |", GET_VAL(head));
 order++;
  head = next(head);
}
}
// Here is the primes filtering function
//-----------------------------------------------------------------
void get_primes(numbers **P, int range, int *size)
{
   numbers *head = *P, *Q = next(*P);
   int sample = GET_VAL(next(head));
   while(pow(sample,2) <= range)
   {
       while(Q != NULL)
       {
           ++iterates;
           if(next(Q) != NULL && GET_VAL(next(Q)) % sample == 0)
           {
               DEL_NODE(&Q,size);
           }
           Q = next(Q);
       }
       head = next(head);
       sample = GET_VAL(head);
       Q = next(head);

   }

}
//----------------------------------------------------------------------------------------------------------------

