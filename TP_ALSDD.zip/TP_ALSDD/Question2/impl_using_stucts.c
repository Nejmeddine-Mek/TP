#include "LINKED_LISTSAM.h"
#include "DYNARR_AM.h"
#include <time.h>
#include <stdlib.h>
#include <windows.h>
void structs_implementation(numbers **head,ARRAY **LIST)
{
    clock_t begin, end;
int range;
    do{
system("cls");
printf(" \n         =================================Menu of available operation=================================\n");
printf("                                        Implementation Using linked lists                              \n");
printf("                                       Implementation Using dynamic arrays                              \n");
printf("          =============================================================================================\n");
int choice;
printf("Please enter your choice:  ");
scanf("%d", &choice);
switch(choice)
{
case 1:
    printf("Please enter a range: ");
    scanf("%d", &range);
    begin = clock();
    primes(head,range);
    end= clock();
    printf("\nExecution time (starts after reading the range!): %3lf seconds", (double)(end-begin)/1000);// basically we just count the time needed to generate and get numbers
    break;                                                                                         // without including the interruption time
case 2:
    printf("Please enter a range: ");
    scanf("%d", &range);
    PRIMES_throARRAYS(LIST,range);
    free(*LIST);
    break;
default:
    MessageBox(NULL,"Option not available!","ERROR", MB_OK | MB_ICONERROR);

}

}while(MessageBox(NULL,"Do you want to quit ?", "QUESTION", MB_YESNO | MB_ICONQUESTION) != 6);
}

