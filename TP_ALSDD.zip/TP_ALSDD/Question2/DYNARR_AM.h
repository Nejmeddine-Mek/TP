#ifndef DYNARR_AM_H_INCLUDED
#include <stdbool.h>
#define DYNARR_AM_H_INCLUDED
typedef struct {
int number;
bool prime;
}ARRAY;

void CREATE(ARRAY **P,int siz)
{
    *P = (ARRAY *)malloc((siz)*sizeof(ARRAY));
}
bool PRIME_STAT(ARRAY *P)
{
 return P->prime;
}
int RET_VAL(ARRAY *P)
{
    return P->number;
}
void ASSIGN_PR(ARRAY **P, bool prime)
{
   (*P)->prime = prime;
}
void FILL_AR(ARRAY **P,int range,int size)
{
    int c = 1;
    ((*P)+0)->number = 2;

    for(int i = 3; i <= range;i+=2)
    {
        ((*P)+c)->number = i;
        ((*P)+c)->prime = 1;
         ++c;
    }
}
#endif // DYNARR_AM_H_INCLUDED
