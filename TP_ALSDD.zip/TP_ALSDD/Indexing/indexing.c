#include "./IndexingHeader.h"
#include "../Question2/Linked_LISTSAM.h"
// this section for functions prototypes

void printrange(numbers *head, int up, int down);
void displayall_primes_between_two_values(numbers* head,int bi,int bs);
indexedlist* create_sublist(numbers **head,int *iterations,int *size);
void print_indexed_list(numbers *head);

//------------------------- ENDS HERE ---------
//_____________________________________________________________________________
/*  In this section of comment I would like to explain our reasoning here, so we firstly take a list of prime numbers
   and a lower bound and an upper bound as well, the upper bound is verified before calling these functions, so that we
   ensure that our code is safe, then for the lis t we passed to the functions below, we will create an indexed list using
   some given range, then we pass that indexed list to a particular search function that locates the @ of the first prime after the lower bound
   *example: Suppose the following case: 
                                                                 LIST : 2  3  5  7  11  13  17  19  23   ( '|' stand for where we have indices, and based on them, we can preform some kind of jumps )
    where the upper bound is 20 and the lower bound is 12               |     |      |       |       |   
    and the range of indexing is 2, the searching algorithm will return the @ of 11, and then we can print all primes after 12 
    using a simple filtering condition. despite that , the user should choose a good indexing range, let us take a look at the same previous example
                                                                   LIST : 2  3  5  7  11  13  17  19  23
                                                                          |            |              |
   while the lower bound is 9 this time, the returned @ will be the 2's address, so, we will take a bit more time going from 2 to 9, even though
   the difference is very slight even on quite large numbers, but as long as we have the indexing method, we should know how to use it wisely 
*/


//______________________________________________________________________________
//___________________________________
clock_t begin, end;
//-------------------------------------------
// creating the sublist in this function

indexedlist* create_sublist(numbers **head,int *iterations,int *size) { // head is the head of the list containing all numbers not just primes to broaden the search process
    int idrange ;
                 // there is an interruption here, so we need to know how long it lasts so that we can get the exact execution time
                    // our functions without the interruption time
     give_range(&idrange); // Get the range from the user
    begin = clock();
    // Traverse the original list to the specified range

    numbers *ptrtest= *head;                                 // this is a temp variable
    for (int i = 0; i < idrange && ptrtest != NULL; i++) {   // just to check if the given range is within the list 
      ++(*iterations);
        ptrtest = next(ptrtest);
    }

    if (ptrtest == NULL) {
        // If the range exceeds the list size, return NULL
        printf("the range exceeded the length of the list .please give a valid range!!\n");
        return NULL;
    }
numbers* ptr2= *head; //pointer to original list helps to iterate it then fill it.


    indexedlist *current = NULL;
    // Create the first number of the sublist with the value from the original list
     subnewcell(&current);
     (*size) += sizeof(indexedlist);
       indexedlist* headsublist=current; // thus is the head we well return from the function which points to the first node
       indexedlist* prev=headsublist;// pointer to previous node
    subAS_VAL(&current, GET_VAL(ptr2)); // Assign the data from the original list numbers
       prev = current; // Update the previous sublist pointer
       indexedlist* ptr=current; // pointer thqt helps to link between the indexeds by their range
       int cpt=1; //coutner to cout the range
       ptr2=next(ptr2);// updating the pointer to the next node in the original list

    while ( ptr2) {
        ++(*iterations);
        subnewcell(&current); 
        (*size) += sizeof(indexedlist);               // Create new numbers for the sublist
        subAS_VAL(&current, GET_VAL(ptr2)); // Assign the data from the original list numbers
        subAS_ADR(&prev,current);          // link previous node to current node
        prev=current;                     // updating prev pointer
        
        cpt++;           //incrementing the counter
        if (cpt==idrange && next(ptr2)){ // checking if it is the wanted node
            ptr2=next(ptr2);
        subnewcell(&current);               // Create new numbers for the sublist
        subAS_VAL(&current, GET_VAL(ptr2)); // Assign the data from the original list numbers
        subAS_ADR(&prev,current);      //link previous node to current node
        subAS_idADR(&ptr,current);    //linking next index
         ptr=current;                 // updating ptr to current index
         prev=current;        // updating previous numbers to current numbers
         cpt=1;           // reloading the counter
    }
    ptr2=next(ptr2); //go to the next node
    }
    return headsublist; // Return the sublist head
}

//----------------------------------------------------------------------------------
// here all we do is printing the indexed list (basically, the wanted set of primes)
void print_indexed_list(numbers *head) {  // print the indexed list not the whole        // do we need this one???
    indexedlist *current = head; // Start from the head of the list
    int value;
    printf("Indexed Linked List: \n");
    while (current != NULL) {
        value = subGET_VAL(current);
        printf("%d ",value);         // Print the data of the current numbers
        current = subnextindex(current); // Move to the next numbers
    }
    printf("\n");
}
// search elements in the list with the optimization of indexing

indexedlist* index_search_el(indexedlist* headsublist, int val) {
    indexedlist* current = subnextindex(headsublist); //initialization of current to the second index
    indexedlist* prev= headsublist;                //initialise prev to head of the list which is first index
    indexedlist* temp= headsublist;         // pointer that helps for special case like the element is greater than last index in sub list but exists in original list
    // Search until the next index node's value is greater than or equal to the target value
    while (current != NULL) {
        if (subGET_VAL(prev)<= val && subGET_VAL(current)>= val){   //specifying the range 
            if(subGET_VAL(current) >= val){
                return prev;
            }                                               // if we find the element between prev and current
            else{                                          //we just print it by traversing the lis after prev
            while (subGET_VAL(prev)!= val){                 
                prev=subnext(prev);
            }
            return prev;
            }
        }
        prev=current;              // updating the pointers
        temp=current;
        current = subnextindex(current); //updating the next index
        
    }
}
//--------------------------------------------------------------------------------------


void displayall_primes_between_two_values(numbers * head,int up,int down){ // up stands for the upper bound, down for lower bound
    indexedlist* head2=NULL;  
        int size = 0, Niterations = 0; // tese are for the space complexity, and the number of iterations

        //initialization of the head of the indexed sublist
    head2=create_sublist(&head,&Niterations,&size);     //call of the function which does it

    int count = 0;  // this var is gonna allow us to print 8 numbers in each line (organizing the output) 

                                      
    indexedlist* temp2=index_search_el(head2,down); //searching the giving values on the  list. 

    if(!temp2){                           //checking if invalid values input
        printf("\n invalid values input !! they dont exist on the list.");
        return;
    }
    while (temp2 != NULL && subGET_VAL(temp2) <= up){ //displaying the primes 
                                         // we look for the very first prime right after the lower bound, which can also be the lower bound
           if(subGET_VAL(temp2) >= down) // itself, that's why we have >= (greater than or equal)
           {
            count++;
            printf("%3d   |",subGET_VAL(temp2));
            if( count % 7 == 0)
            {
                printf("\n");
            }
           }

        temp2=subnext(temp2); //linear updating to get all the primes
    }
    end = clock();
    printf("\n");
    printf("Execution time:  %3lf seconds\n", (double)(end-begin)/1000);
    printf("Space complexity:  %3d bytes\n", size);
    printf("Number of iteration: %3d", Niterations);
}