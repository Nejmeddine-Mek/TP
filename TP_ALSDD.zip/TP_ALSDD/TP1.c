#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include "Question2/Linked_LISTSAM.h"
#include "Question2/impl_using_stucts.c"
#include "Question2/LLS_PR.c"
#include "Question1/Functions.h"
#include "Question1/Static_Representation.c"
#include "Question2/DYNARR_AM.h"
#include "Dyn_Method.c"

// Here our program begins
int main(char args, int *argv[])
{
    ARRAY *V; // I NEED TO GIVE YOU A GOOD NAME!!
    numbers *head;
system("COLOR B");
BOOL MessageBeep(UINT uType);
int response;

do{
   system("cls");
//---------------------------------------------------Menu-----------------------------------------------
//------------------------------------------------------------------------------------------------------
printf("          =================================Menu of available operation=================================\n");
printf("\n                           Get list of prime numbers in a given range (Quick display)                  \n");
printf("                     Get Prime numbers of a given range using dynamic arrays or linked lists                   \n");
printf("                                             Get list of co-primes                                     \n");
printf("                                        Get primes product of a number                                 \n");
printf("          =============================================================================================\n");
        printf("\nPlease enter your choice:  ");
        int choice = 0;
        scanf("%d", &choice);
        switch(choice)
        {
        case 1:
            // getting quick display
            GET_PRIMES();
            break;
        case 2:
            structs_implementation(&head,&V);
            break;
        case 3:
            // getting prime numbers using linked lists method!

            break;
        case 4:

            break;
        case 5:
        // prime factorization
            break;
        case 6:

            break;
        default:
            MessageBeep(MB_ICONERROR);
            MessageBox(NULL,"Option not available","ERROR", MB_ICONERROR| MB_OK);
            break;
        }
   MessageBeep(MB_ICONASTERISK);


   response = MessageBox(NULL,"Would you like to quit the program?","Message",MB_ICONQUESTION | MB_YESNO);
}while(response != IDYES);
    //There is always a delay of approximately order 10^(-1) due to the time between the print flow
   // and the actual exit of the program
    return 0;
}

