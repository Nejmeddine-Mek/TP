#include <stdio.h> // we are including necessary headers and files !
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <stdbool.h>  
#include "Question2/Linked_LISTSAM.h" // Abstract machine of linked lists
#include "Question2/impl_using_stucts.c" // implementation using complex structres (linkde lists, dynamic arrays)
#include "Question2/LLS_PR.c" // linked lists presentation
#include "Question1/Functions.h" // static presentaion functions
#include "Question1/Static_Representation.c" // static representation main 
#include "Question2/DYNARR_AM.h" // dynamic arrays abstract machine
#include "Question2/Dyn_Method.c" // dynamic arrays implementaiton
#include "Question3/Comparison.c" // comparison between both methods
#include "Question4/FACTLLSAM.h" // factorization structure abstract machine
#include "Question4/FACTORIZE.c" // the implemetnation of the factorization
#include "CoPrimes/COPrimes.c" // coprimes
#include "intro.c" // intro
#include "Indexing/IndexingHeader.h"
#include "Indexing/indexing.c" // indexing by range
// Here our program begins
//--------------------------------
//----------------------
int main(char args, int *argv[])
{  //BEGIN
    intro();     // we call the intro function; all it prints is the title of this work!
    getch();    // we keep it until we read some key pressing through this function to proceed
    // now here we declare the most important variables that we will be using in the upcoming functions

    ARRAY *V;                   // this pointer will point to the array we will create !
    numbers *head = NULL;       // this one will point to the head of the list
    FACT *ListOfFactors = NULL; // this will point to the head of the lists of factorized numbers

    system("COLOR B");            // set colour to light blue
    BOOL MessageBeep(UINT uType);// This will make some sounds later on!
    int response,range;         // we will  use these variables to read some input 
printf("\nyou can switch options using keyboard arrows!");
    sleep(1);
  // this do while() loop will make our program repetitive 
do{ // begins here
   system("cls"); // we clear the screen

int choice = menu(); // we display our keyboard controlled menu, and this function returns the choice so that we can go ahead  
                     // and run a function from those below
                     // the good thing is that we can give up on the default case as the user now is limited by a given number of
                    // choices
        switch(choice)
        {
        case 1:
            // getting quick display
            GET_PRIMES(); // calling the function that displays primes in a given range
                          // it doesn't use any structures; more details are provided within the Static_representation and Fucnitons files
            break;
       //---------------------------- End of the first option------------------------
       //***************************************************************************    
        case 2:
          newlist: // the reason of adding this label is down in the indexing question
        // we redirect the user where they will choose either linked lists presentation or dynamic arrays representation 
           range = structs_implementation(&head,&V); // the name stands for implementation using structures
                                                    // we redirect the user to another menu to choose one of the available
                                                   // methods to generate prime numbers in that given range, then we return 
                                                  //  the range as we will use it later on
            break;
       //---------------------------- End of the second option------------------------
       //***************************************************************************    

        case 3:
             // we index the list then we print by index
        if(head == NULL)
        {
            printf("You must create a list of prime numbers first!\n"); // if there is no list, there is no indexing and printing 
        }
        else
        {
            int up, down;
            printf("lower bound: ");
            scanf("%d", &down);
            while(down < 0)
            {
                printf("There are no negative primes, please enter a postive value that is greater than or equal to 2 :  ");
                scanf("%d", &down);
            }
            printf("upper bound: ");
            scanf("%d", &up);
            while( up > range || up < down)
            {
                printf("The upper bound you entered is too big so that is exceeds %d, or it is less than \n", range);
                printf(" The lower bound\n");
                printf("ENter a new upper bound or type in -1 to create a new list with a new range");
                scanf("%d", &up);
                if(up == -1)
                {                         // in order not to make the user repeat his choice in the main menu, we create this loop, so that
                                        // we force them to enter som kind of a valid range [lower bound ...... upper bound], or if they want to
                                      // create a bigger list for that range, they can enter -1 and then go to create a new list to work with it!  
                    /* More explanation:
                         here, we make sure that all conditions are satisfied;
                         1/  up >> down
                         2/  up is withing the range
                         3/ up > 0, just by making sure that down is positive and greater than or equal to 2 
                    
                    
                    
                    */
                       
                    
                    goto newlist;
                }
            }
            displayall_primes_between_two_values(head,up,down); // we get the list and withing the function we get the upper and the lower bounds,
            // printrange(head,up,down);                  // we print primes between these values

        }
            break;
       //---------------------------- End of the fourth option------------------------
       //*************************************************************************** 
        case 4:
                 // primes factorization
            if(head == NULL)
            {
                printf("You must Create a list of prime numbers first (using linked lists)!"); // obviously, the creation of the list 
                                                                                            // is necessary to progress
            }
            else
            {
              Factorize(range,&ListOfFactors,head); // i it it created we go forwards and factorize
            }
            break;
       //---------------------------- End of the fifth option------------------------
       //*************************************************************************** 
        case 5:
                 // co-primes!!
        if( ListOfFactors == NULL)
        {
            printf("\nYou must get the list of factorized numbers first! it is option 5 in the main menu!"); // again, the list of factorized
                                                                                                            // numbers is necessary
        }
        else
        {
         CoPrimes(ListOfFactors);   // if the list exists we proceed to the function

        }
            break;
       //---------------------------- End of the sixth option------------------------
       //*************************************************************************** 
          case 6:
        // we compare the stuctures 
            Compare();  // here we call the function that does the comparison for us
                        // Just to clarify a point, we redirect the user to this function regardless of his previous choices
                        // i.e: we don't consider the created linked list or array, because they may have different ranges so 
                        // the comparison won't be fair, hence we ask for one range and do the whole work again, on the same range 
                        // then we display the result
            break;
       //---------------------------- End of the third option------------------------
       //*************************************************************************** 
        case 7:
            goto end;  // here if the user chooses to quit, we go to the label end; it is found below, so that we close the program
            break;
       //---------------------------- End of the seventh option------------------------
       //*************************************************************************** 
        default:
            MessageBeep(MB_ICONERROR);                                             // if we run into some errors, this command makes an error sound
            MessageBox(NULL,"Option not available","ERROR", MB_ICONERROR| MB_OK); // and this here displays a message box indicating that 
                                                                                 // the chosen option is not available
            break;
        }
          //  sleep(2); // (pause for 2 seconds then continue executing)
   MessageBeep(MB_ICONASTERISK); // here an informatin sound 
   response = MessageBox(NULL,"Would you like to quit the program?","Message",MB_ICONQUESTION | MB_YESNO); // we ask if the user wants to quit or not!
}while(response != IDYES);           // we quit if their response is yes! (loop ends here)
   end:                              // this label is basically created for the seventh case if we want to quit right away
    return 0;
} //END